package com.sarthak.usagetracker;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;

import androidx.core.content.res.ResourcesCompat;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class FgEventObject {

    private String appName;
    private String packageName;
    private Date startTime, endTime;

    public long getCumulativeDuration() {
        return cumulativeDuration;
    }

    private long cumulativeDuration;

    FgEventObject(String appName, String packageName, String startTime, String endTime) throws ParseException {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        this.appName = appName;
        this.packageName = packageName;
        this.startTime = df.parse(startTime);
        this.endTime = df.parse(endTime);
        this.cumulativeDuration = 0;
    }

    public List<Long> getDuration(){
        long duration = new Date(this.endTime.getTime() - this.startTime.getTime()).getTime();

        long days = TimeUnit.MILLISECONDS.toDays(duration);
        duration -= TimeUnit.DAYS.toMillis(days);

        long hours = TimeUnit.MILLISECONDS.toHours(duration);
        duration -= TimeUnit.HOURS.toMillis(hours);

        long minutes = TimeUnit.MILLISECONDS.toMinutes(duration);
        duration -= TimeUnit.MINUTES.toMillis(minutes);

        long seconds = TimeUnit.MILLISECONDS.toSeconds(duration);

        return Arrays.asList(days, hours, minutes, seconds);
    }

    public String getStartDateAsString(){
        return new SimpleDateFormat("dd-MM-yyyy").format(startTime);
    }

    public String getStartTimeAsString(){
        return new SimpleDateFormat("KK:mm a").format(startTime);
    }

    public String getEndTimeAsString(){
        return new SimpleDateFormat("KK:mm a").format(endTime);
    }

    public Drawable getPackageIcon(Context context) throws PackageManager.NameNotFoundException {

        if(packageName.equals(CONSTANTS.DEVICE_LOCKED_PACKAGE_NAME) || appName.equals(CONSTANTS.DEVICE_LOCKED_APP_NAME)){
            return context.getDrawable(R.drawable.locked_icon);
        }

        return context.getPackageManager().getApplicationIcon(packageName);
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public long getDurationInSeconds() {
        long duration = new Date(this.endTime.getTime() - this.startTime.getTime()).getTime();

        return TimeUnit.MILLISECONDS.toSeconds(duration);
    }

    public void addCumulativeDuration(long seconds) {
        this.cumulativeDuration += seconds;
    }

    public List<Long> getFormattedCumulativeDuration(){
        long seconds = cumulativeDuration;

        long days = TimeUnit.SECONDS.toDays(seconds);
        long hours = TimeUnit.SECONDS.toHours(seconds) - (days * 24L);
        long minutes = TimeUnit.SECONDS.toMinutes(seconds) - (TimeUnit.SECONDS.toHours(seconds)* 60);
        long second = TimeUnit.SECONDS.toSeconds(seconds) - (TimeUnit.SECONDS.toMinutes(seconds) *60);

        return Arrays.asList(days, hours, minutes, second);
    }

    public void setCumulativeDuration(long cumulativeDuration) {
        this.cumulativeDuration = cumulativeDuration;
    }
}
