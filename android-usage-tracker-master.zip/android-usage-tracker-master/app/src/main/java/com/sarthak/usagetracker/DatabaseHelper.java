package com.sarthak.usagetracker;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    Context mContext;
    SimpleDateFormat sdf;
    SimpleDateFormat dateOnlyFormat, timeOnlyFormat, timezoneFormat;
    SQLiteDatabase db;

    public DatabaseHelper(@Nullable Context context) {
        super(context, CONSTANTS.DATABASE_NAME, null, 1);
        mContext = context;

        db = this.getWritableDatabase();
        sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", mContext.getResources().getConfiguration().locale);
        dateOnlyFormat = new SimpleDateFormat("yyyy-MM-dd", mContext.getResources().getConfiguration().locale);
        timeOnlyFormat = new SimpleDateFormat("HH:mm:ss", mContext.getResources().getConfiguration().locale);
        timezoneFormat = new SimpleDateFormat("ZZZZZ", mContext.getResources().getConfiguration().locale);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE " + CONSTANTS.FG_EVENT_DETAILS_TABLE +
                " (id INTEGER PRIMARY KEY AUTOINCREMENT, event_name TEXT, event_package_name TEXT)"
        );
        db.execSQL(
                "CREATE TABLE " + CONSTANTS.FG_EVENT_TABLE +
                " (id INTEGER PRIMARY KEY AUTOINCREMENT, event_id INTEGER, start_date TEXT, start_time TEXT, start_timezone TEXT, end_date TEXT, end_time TEXT, end_timezone TEXT," +
                        " FOREIGN KEY (event_id) REFERENCES " + CONSTANTS.FG_EVENT_DETAILS_TABLE + "  (id) )"
        );

        db.execSQL(
                "CREATE TABLE " + CONSTANTS.NETWORK_DATA_SSID_TABLE +
                        " (id INTEGER PRIMARY KEY AUTOINCREMENT, ssid TEXT)"
        );

        db.execSQL(
                "CREATE TABLE " + CONSTANTS.NETWORK_EVENTS_TABLE +
                        " (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, time TEXT, timezone TEXT, ssid_id INTEGER, is_wifi INTEGER, strength TEXT," +
                        " FOREIGN KEY (ssid_id) REFERENCES " + CONSTANTS.NETWORK_DATA_SSID_TABLE + " (id) )"
        );

        db.execSQL("CREATE TABLE " + CONSTANTS.SENSOR_DATA_TABLE +
                " (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, time TEXT, timezone TEXT, " +
                "accel_x TEXT, accel_y TEXT, accel_z TEXT, " +
                "gyro_x TEXT, gyro_y TEXT, gyro_z TEXT, " +
                "mag_x TEXT, mag_y TEXT, mag_z TEXT, light TEXT)");

        db.execSQL("CREATE TABLE " + CONSTANTS.BATTERY_EVENTS_TABLE +
                " (id INTEGER PRIMARY KEY AUTOINCREMENT, event_type TEXT, percentage TEXT, date TEXT, time TEXT, timezone TEXT)");

        db.execSQL("CREATE TABLE " + CONSTANTS.CALL_STATUS_TABLE +
                " (id INTEGER PRIMARY KEY AUTOINCREMENT, mode TEXT, date TEXT, time TEXT, timezone TEXT)");

        db.execSQL("CREATE TABLE " + CONSTANTS.METADATA_TABLE +
                " (property TEXT, value TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + CONSTANTS.FG_EVENT_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + CONSTANTS.FG_EVENT_DETAILS_TABLE);

        onCreate(db);
    }

    public File exportRawDB(){
        File file = null;
        String fileName = "usage-tracker-rawDB.db";
        String newPath = mContext.getFileStreamPath("").toString();
        Log.d("LOG PRINT SHARE DB", "newPath found, Here is string: " + newPath);
        String oldPath = mContext.getDatabasePath(CONSTANTS.DATABASE_NAME).toString();
        Log.d("LOG PRINT SHARE DB", "oldPath found, Her is string: " + oldPath);
        try {
            File f = new File(newPath);
            f.mkdirs();
            FileInputStream fin = new FileInputStream(oldPath);
            FileOutputStream fos = new FileOutputStream(newPath + "/" + fileName);
            byte[] buffer = new byte[1024];
            int len1 = 0;
            while ((len1 = fin.read(buffer)) != -1) {
                fos.write(buffer, 0, len1);
            }
            fin.close();
            fos.close();
            file = new File(newPath + "/" + fileName);
            if (file.exists())
                return file;
        } catch (Exception e) {

        }
        return null;    }

    public File exportEventDB() {

        File exportDir = new File(mContext.getFilesDir(), "");
        if (!exportDir.exists())
        {
            exportDir.mkdirs();
        }

        File file = new File(exportDir, "fg_events.csv");
        try
        {
            file.createNewFile();
            au.com.bytecode.opencsv.CSVWriter csvWrite = new au.com.bytecode.opencsv.CSVWriter(new FileWriter(file));

            SQLiteDatabase db = this.getReadableDatabase();

            Cursor cursor = db.rawQuery("SELECT foreground_events.id as id, start_date, start_time, start_timezone, end_date, end_time, end_timezone, event_package_name, event_name  FROM foreground_events INNER JOIN foreground_event_details ON foreground_event_details.id = foreground_events.event_id", null);

            csvWrite.writeNext(cursor.getColumnNames());

            while(cursor.moveToNext())
            {
                //Which column you want to exprort
                String[] arrStr ={cursor.getString(0),cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getString(6), cursor.getString(7), cursor.getString(8)};
                csvWrite.writeNext(arrStr);
            }
            csvWrite.close();
            cursor.close();
        }
        catch(Exception sqlEx)
        {
            Log.e("MainActivity", sqlEx.getMessage(), sqlEx);
        }

        return file;
    }

    public File exportNetworkDB() {

        File exportDir = new File(mContext.getFilesDir(), "");
        if (!exportDir.exists())
        {
            exportDir.mkdirs();
        }

        File file = new File(exportDir, "network_data.csv");
        try
        {
            file.createNewFile();
            au.com.bytecode.opencsv.CSVWriter csvWrite = new au.com.bytecode.opencsv.CSVWriter(new FileWriter(file));

            SQLiteDatabase db = this.getReadableDatabase();

            Cursor cursor = db.rawQuery("SELECT network_events.id as id, date, time, timezone, ssid, is_wifi, strength  FROM network_events INNER JOIN network_details ON network_events.ssid_id = network_details.id", null);

            csvWrite.writeNext(cursor.getColumnNames());

            while(cursor.moveToNext())
            {
                //Which column you want to exprort
                String[] arrStr ={cursor.getString(0),cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getString(6)};
                csvWrite.writeNext(arrStr);
            }
            csvWrite.close();
            cursor.close();
        }
        catch(Exception sqlEx)
        {
            Log.e("MainActivity", sqlEx.getMessage(), sqlEx);
        }

        return file;
    }

    public File exportSensorDB() {

        File exportDir = new File(mContext.getFilesDir(), "");
        if (!exportDir.exists())
        {
            exportDir.mkdirs();
        }

        File file = new File(exportDir, "sensor_data.csv");
        try
        {
            file.createNewFile();
            au.com.bytecode.opencsv.CSVWriter csvWrite = new au.com.bytecode.opencsv.CSVWriter(new FileWriter(file));

            SQLiteDatabase db = this.getReadableDatabase();

            Cursor cursor = db.rawQuery("SELECT * FROM " + CONSTANTS.SENSOR_DATA_TABLE, null);

            csvWrite.writeNext(cursor.getColumnNames());

            while(cursor.moveToNext())
            {
                //Which column you want to export
                String[] arrStr ={cursor.getString(0),cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getString(6), cursor.getString(7), cursor.getString(8), cursor.getString(9), cursor.getString(10)};
                csvWrite.writeNext(arrStr);
            }
            csvWrite.close();
            cursor.close();
        }
        catch(Exception sqlEx)
        {
            Log.e("MainActivity", sqlEx.getMessage(), sqlEx);
        }

        return file;
    }

    public File exportBatteryDB() {

        File exportDir = new File(mContext.getFilesDir(), "");
        if (!exportDir.exists())
        {
            exportDir.mkdirs();
        }

        File file = new File(exportDir, "battery_charging_data.csv");
        try
        {
            file.createNewFile();
            au.com.bytecode.opencsv.CSVWriter csvWrite = new au.com.bytecode.opencsv.CSVWriter(new FileWriter(file));

            SQLiteDatabase db = this.getReadableDatabase();

            Cursor cursor = db.rawQuery("SELECT * FROM " + CONSTANTS.BATTERY_EVENTS_TABLE, null);

            csvWrite.writeNext(cursor.getColumnNames());

            while(cursor.moveToNext())
            {
                String[] arrStr ={cursor.getString(0),cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5)};
                csvWrite.writeNext(arrStr);
            }
            csvWrite.close();
            cursor.close();
        }
        catch(Exception sqlEx)
        {
            Log.e("MainActivity", sqlEx.getMessage(), sqlEx);
        }

        return file;
    }

    public List<FgEventObject> getAllFgEvents(String startTime, String endTime) throws ParseException {
        List<FgEventObject> toReturn = new ArrayList<>();

        Cursor cursor = db.rawQuery("SELECT * FROM foreground_events INNER JOIN foreground_event_details ON foreground_event_details.id = foreground_events.event_id where foreground_events.start_date >= ? and foreground_events.start_date <= ?", new String[] {startTime, endTime});

        if(cursor.moveToFirst()){
            do {
                FgEventObject event = new FgEventObject(
                        cursor.getString(cursor.getColumnIndex(CONSTANTS.EVENT_NAME_COL)),
                        cursor.getString(cursor.getColumnIndex(CONSTANTS.EVENT_PACKAGE_NAME_COL)),
                        cursor.getString(cursor.getColumnIndex(CONSTANTS.START_DATE_COL)) + "T" +
                        cursor.getString(cursor.getColumnIndex(CONSTANTS.START_TIME_COL)) +
                        cursor.getString(cursor.getColumnIndex(CONSTANTS.START_TIMEZONE_COL)),
                        cursor.getString(cursor.getColumnIndex(CONSTANTS.END_DATE_COL)) + "T" +
                                cursor.getString(cursor.getColumnIndex(CONSTANTS.END_TIME_COL)) +
                                cursor.getString(cursor.getColumnIndex(CONSTANTS.END_TIMEZONE_COL))
                );
                toReturn.add(event);
            } while (cursor.moveToNext());
        }

        cursor.close();

        return toReturn;
    }

    public List<FgEventObject> getAllFgEvents() throws ParseException {
        List<FgEventObject> toReturn = new ArrayList<>();

        Cursor cursor = db.rawQuery("SELECT  *  FROM foreground_events INNER JOIN foreground_event_details ON foreground_event_details.id = foreground_events.event_id", null);

        if(cursor.moveToFirst()){
            do {
                FgEventObject event = new FgEventObject(
                        cursor.getString(cursor.getColumnIndex(CONSTANTS.EVENT_NAME_COL)),
                        cursor.getString(cursor.getColumnIndex(CONSTANTS.EVENT_PACKAGE_NAME_COL)),
                        cursor.getString(cursor.getColumnIndex(CONSTANTS.START_TIME_COL)),
                        cursor.getString(cursor.getColumnIndex(CONSTANTS.END_TIME_COL))
                );
                toReturn.add(event);
            } while (cursor.moveToNext());
        }

        cursor.close();

        return toReturn;
    }

    public boolean insertSensorDataSample(float[] accelerometer, float[] gyroscope, float[] magneticValues, float light, Date timestamp){
        ContentValues values = new ContentValues();

        values.put(CONSTANTS.SENSOR_ACCEL_X_COL, accelerometer[0]);
        values.put(CONSTANTS.SENSOR_ACCEL_Y_COL, accelerometer[1]);
        values.put(CONSTANTS.SENSOR_ACCEL_Z_COL, accelerometer[2]);

        values.put(CONSTANTS.SENSOR_GYRO_X_COL, gyroscope[0]);
        values.put(CONSTANTS.SENSOR_GYRO_Y_COL, gyroscope[1]);
        values.put(CONSTANTS.SENSOR_GYRO_Z_COL, gyroscope[2]);

        values.put(CONSTANTS.SENSOR_MAGNET_X_COL, magneticValues[0]);
        values.put(CONSTANTS.SENSOR_MAGNET_Y_COL, magneticValues[1]);
        values.put(CONSTANTS.SENSOR_MAGNET_Z_COL, magneticValues[2]);

        values.put(CONSTANTS.SENSOR_LIGHT_COL, light + "");

        values.put(CONSTANTS.SENSOR_DATE_COL, dateOnlyFormat.format(timestamp));
        values.put(CONSTANTS.SENSOR_TIME_COL, timeOnlyFormat.format(timestamp));
        values.put(CONSTANTS.SENSOR_TIMEZONE_COL, timezoneFormat.format(timestamp));

        return db.insert(CONSTANTS.SENSOR_DATA_TABLE, null, values) > 0;
    }

    public boolean insertEvent(String packageName, String appName, int appID, Date startTime, Date endTime){
        ContentValues values = new ContentValues();
        values.put(CONSTANTS.EVENT_ID_COL, appID);
        values.put(CONSTANTS.START_DATE_COL, dateOnlyFormat.format(startTime));
        values.put(CONSTANTS.END_DATE_COL, dateOnlyFormat.format(endTime));
        values.put(CONSTANTS.START_TIME_COL, timeOnlyFormat.format(startTime));
        values.put(CONSTANTS.END_TIME_COL, timeOnlyFormat.format(endTime));
        values.put(CONSTANTS.START_TIMEZONE_COL, timezoneFormat.format(startTime));
        values.put(CONSTANTS.END_TIMEZONE_COL, timezoneFormat.format(endTime));

        return db.insert(CONSTANTS.FG_EVENT_TABLE, null, values) > 0;
    }

    public boolean insertNetworkEvent(String ssid, int ssidID, int isWifi, float strength, Date timestamp){
        ContentValues values = new ContentValues();
        values.put(CONSTANTS.NETWORK_EVENT_DATE_COL, dateOnlyFormat.format(timestamp));
        values.put(CONSTANTS.NETWORK_EVENT_TIME_COL, timeOnlyFormat.format(timestamp));
        values.put(CONSTANTS.NETWORK_EVENT_TIMEZONE_COL, timezoneFormat.format(timestamp));
        values.put(CONSTANTS.NETWORK_EVENT_SSID_ID, ssidID);
        values.put(CONSTANTS.NETWORK_EVENT_ISWIFI_COL, isWifi);
        values.put(CONSTANTS.NETWORK_STRENGTH_COL, strength);

        return db.insert(CONSTANTS.NETWORK_EVENTS_TABLE, null, values) > 0;
    }

    public boolean insertBatteryEvent(String eventType, int percentage, Date timestamp){
        ContentValues values = new ContentValues();
        values.put(CONSTANTS.BATTERY_EVENT_TYPE, eventType);
        values.put(CONSTANTS.BATTERY_PERCENTAGE_COL, percentage + "");
        values.put(CONSTANTS.BATTERY_DATE_COL, dateOnlyFormat.format(timestamp));
        values.put(CONSTANTS.BATTERY_TIME_COL, timeOnlyFormat.format(timestamp));
        values.put(CONSTANTS.BATTERY_TIMEZONE_COL, timezoneFormat.format(timestamp));

        return db.insert(CONSTANTS.BATTERY_EVENTS_TABLE, null, values) > 0;
    }

    public boolean insertCallStatusEvent(String mode, Date timestamp){
        ContentValues values = new ContentValues();
        values.put(CONSTANTS.CALL_MODE_COL, mode);
        values.put(CONSTANTS.CALL_STATUS_DATE_COL, dateOnlyFormat.format(timestamp));
        values.put(CONSTANTS.CALL_STATUS_TIME_COL, timeOnlyFormat.format(timestamp));
        values.put(CONSTANTS.CALL_STATUS_TIMEZONE_COL, timezoneFormat.format(timestamp));

        return db.insert(CONSTANTS.CALL_STATUS_TABLE, null, values) > 0;
    }

    public boolean insertMetadataProperty(String property, String value){
        ContentValues values = new ContentValues();
        values.put(CONSTANTS.METADATA_PROPERTY_NAME_COL, property);
        values.put(CONSTANTS.METADATA_PROPERTY_VALUE_COL, value);

        return db.insert(CONSTANTS.METADATA_TABLE, null, values) > 0;
    }

    public int registerEvent(String packageName, String appName){
        ContentValues values = new ContentValues();
        values.put(CONSTANTS.EVENT_NAME_COL, appName);
        values.put(CONSTANTS.EVENT_PACKAGE_NAME_COL, packageName);

        db.insert(CONSTANTS.FG_EVENT_DETAILS_TABLE, null, values);

        final String query = "SELECT last_insert_rowid() FROM " + CONSTANTS.FG_EVENT_DETAILS_TABLE;
        Cursor cur = db.rawQuery(query, null);
        cur.moveToFirst();
        int ID = cur.getInt(0);
        cur.close();
        return ID;
    }

    public int registerSSID(String ssid){
        ContentValues values = new ContentValues();
        values.put(CONSTANTS.NETWORK_DATA_SSID, ssid);

        db.insert(CONSTANTS.NETWORK_DATA_SSID_TABLE, null, values);

        final String query = "SELECT last_insert_rowid() FROM " + CONSTANTS.NETWORK_DATA_SSID_TABLE;
        Cursor cur = db.rawQuery(query, null);
        cur.moveToFirst();
        int ID = cur.getInt(0);
        cur.close();
        return ID;
    }

    public HashMap<String, Integer> getAllRegisteredEvents(){
        Cursor cursor = db.rawQuery("SELECT * FROM " + CONSTANTS.FG_EVENT_DETAILS_TABLE, null);

        HashMap<String, Integer> map = new HashMap<>();

        if(cursor.moveToFirst()){
            do{
                map.put(cursor.getString(cursor.getColumnIndex(CONSTANTS.EVENT_NAME_COL)),
                        cursor.getInt(cursor.getColumnIndex(CONSTANTS.ID_COL)));
            } while(cursor.moveToNext());
        }

        return map;
    }

    public HashMap<String, Integer> getAllRegisteredSSIDs(){
        Cursor cursor = db.rawQuery("SELECT * FROM " + CONSTANTS.NETWORK_DATA_SSID_TABLE, null);

        HashMap<String, Integer> map = new HashMap<>();

        if(cursor.moveToFirst()){
            do{
                map.put(cursor.getString(cursor.getColumnIndex(CONSTANTS.NETWORK_DATA_SSID)),
                        cursor.getInt(cursor.getColumnIndex(CONSTANTS.NETWORK_DATA_SSID_ID)));
            } while(cursor.moveToNext());
        }

        return map;
    }
}
