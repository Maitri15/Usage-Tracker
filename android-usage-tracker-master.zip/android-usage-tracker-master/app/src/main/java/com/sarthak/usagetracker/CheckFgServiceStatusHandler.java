package com.sarthak.usagetracker;

import android.app.ActivityManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.preference.PreferenceManager;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

public class CheckFgServiceStatusHandler extends BroadcastReceiver {

    final String CHANNEL_ID = "service_stopped_notification_channel_id";

    @Override
    public void onReceive(Context context, Intent intent) {

        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(context);
        boolean isPollingActive = sharedPref.getBoolean(CONSTANTS.IS_POLLING_ACTIVE, false);

        if(!isMyServiceRunning(context, ForegroundService.class) && isPollingActive) {
            Intent startIntent = new Intent(context, ForegroundService.class);
            startIntent.setAction(CONSTANTS.START_FOREGROUND_SERVICE);
            ContextCompat.startForegroundService(context, startIntent);
        }

    }

    private boolean isMyServiceRunning(Context context, Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
}