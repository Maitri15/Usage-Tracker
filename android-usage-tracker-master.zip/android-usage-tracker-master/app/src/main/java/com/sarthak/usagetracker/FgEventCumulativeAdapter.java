package com.sarthak.usagetracker;

import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FgEventCumulativeAdapter extends RecyclerView.Adapter<FgEventCumulativeAdapter.ViewHolder> {

    private Context context;
    private int resource;
    List<FgEventObject> list = new ArrayList<>();

    public FgEventCumulativeAdapter(Context context, int resource, List<FgEventObject> list1){
        this.context = context;
        this.resource = resource;

        HashMap<String, FgEventObject> map = new HashMap<>();

        for(FgEventObject event: list1){

            if(map.containsKey(event.getAppName())){
                map.get(event.getAppName()).addCumulativeDuration(event.getDurationInSeconds());
            }
            else{
                FgEventObject eventObject = null;
                try {
                    eventObject = new FgEventObject(event.getAppName(), event.getPackageName(), "2021-10-10T19:59:11+0530", "2021-10-10T19:59:11+0530");
                    eventObject.setStartTime(event.getStartTime());
                    eventObject.setEndTime(event.getEndTime());
                } catch (ParseException e) {
                    Log.e("CUMULATIVE ERROR", e.toString());
                }

                eventObject.addCumulativeDuration(eventObject.getDurationInSeconds());
                map.put(eventObject.getAppName(), eventObject);
            }
        }

        for(String key: map.keySet()){
            this.list.add(map.get(key));
        }

        Collections.sort(list, new Comparator<FgEventObject>() {
            @Override
            public int compare(FgEventObject fgEventObject, FgEventObject t1) {
                return Long.compare(fgEventObject.getCumulativeDuration(), t1.getCumulativeDuration());
            }
        });

        Collections.reverse(list);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(resource, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.appName.setText(list.get(position).getAppName());
        holder.date.setVisibility(View.GONE);
        holder.time.setVisibility(View.GONE);
        try {
            holder.packageIcon.setImageDrawable(list.get(position).getPackageIcon(context));
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        List<Long> duration = list.get(position).getFormattedCumulativeDuration();
        String durationStr = "";

        if (duration.get(0) != 0){
            durationStr = durationStr + duration.get(0) + " days";
        }

        if (duration.get(1) != 0){
            durationStr = durationStr + duration.get(1) + " h ";
        }

        if (duration.get(2) != 0){
            durationStr = durationStr + duration.get(2) + " m ";
        }

        if (duration.get(3) != 0){
            durationStr = durationStr + duration.get(3) + " s";
        }

        holder.duration.setText(durationStr);
    }

    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private TextView appName, date, time, duration;
        private ImageView packageIcon;

        public ViewHolder(@NonNull View view) {
            super(view);

            this.appName = view.findViewById(R.id.fg_item_appName);
            this.date = view.findViewById(R.id.fg_item_date);
            this.time = view.findViewById(R.id.fg_item_time);
            this.duration = view.findViewById(R.id.fg_item_duration);
            this.packageIcon = view.findViewById(R.id.fg_item_packageIcon);
        }
    }
}
