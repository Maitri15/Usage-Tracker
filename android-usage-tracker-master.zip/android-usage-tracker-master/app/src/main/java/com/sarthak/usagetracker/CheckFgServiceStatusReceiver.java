package com.sarthak.usagetracker;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

public class CheckFgServiceStatusReceiver extends BroadcastReceiver {

    final String CHANNEL_ID = "service_stopped_notification_channel_id";

    @Override
    public void onReceive(Context context, Intent intent) {

        if(!isMyServiceRunning(context, ForegroundService.class)) {
            createNotificationChannel(context);
            createNotification(context);
            Log.e("DEBUG", "Service was not running, started from onReceive method of AlarmManager.");
            Intent startIntent = new Intent(context, ForegroundService.class);
            startIntent.setAction(CONSTANTS.START_FOREGROUND_SERVICE);
            ContextCompat.startForegroundService(context, startIntent);
        }

    }

    private void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Application Status";
            String description = "Sends notification if the background service has stopped running.";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void createNotification(Context context){
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.activity_tracker_icon)
                .setContentTitle("Usage Tracker")
                .setOnlyAlertOnce(true)
                .setContentText("Background service has stopped. Please reopen the app to restart the service.")
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText("Background service has stopped. Please reopen the app to restart the service."))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);

        notificationManager.notify(1234, builder.build());
    }

    private boolean isMyServiceRunning(Context context, Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
}