package com.sarthak.usagetracker;

import static androidx.core.content.PermissionChecker.PERMISSION_GRANTED;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.AppOpsManager;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.provider.SyncStateContract;
import android.util.Log;
import android.util.StatsLog;
import android.view.View;
import android.widget.Button;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.io.File;
import java.security.Permission;
import java.time.LocalDateTime;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    SwitchMaterial pollingSwitch;
    Button launchFgEventOverviewScreen, btnExportFGEventData, btnExportSensorData, btnExportNetworkData, btnExportBatteryData, btnExportRawDB;

    Boolean isPollingActive = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        requestUsageStatsPermission();

        initializeListenersAndUI();

        registerRepeatingServiceRestarterAlarm();

        registerRepeatingServiceCheckerAlarm();

        if(!isMyServiceRunning(ForegroundService.class) && isPollingActive) {
            switchStateChanged();
        }

        pollingSwitch.setOnClickListener(v -> switchStateChanged());

        // First call to database. (Database init)
        DatabaseHelper dbHelper = new DatabaseHelper(getBaseContext());

        getDeviceInfo();
//
//        Intent intent = new Intent(this, CheckFgServiceStatusHandler.class);
//        boolean alarmUp = (PendingIntent.getBroadcast(getApplicationContext(), 0,
//                intent,
//                PendingIntent.FLAG_NO_CREATE) != null);
//
//        if (alarmUp) {
//            Log.d("myTag", "Alarm is already active");
//        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        check_first_launch();
    }

    void check_first_launch(){
        SharedPreferences prefs = getSharedPreferences("com.sarthak.usagetracker", MODE_PRIVATE);

        if (prefs.getBoolean("firstrun", true)) {

            RequestQueue queue = Volley.newRequestQueue(this);
            String url ="https://api.countapi.xyz/hit/androidusagetracker/installs";

            // Request a string response from the provided URL.
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    response -> {
                        prefs.edit().putBoolean("firstrun", false).apply();
                    }, error -> {
                        Log.e("ERROR", "GET request failed!");
                    });

            queue.add(stringRequest);
        }
    }

    void getDeviceInfo(){

        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);

        if(!sharedPref.getBoolean("is_device_info_recorded", false)) {
            DatabaseHelper dbHelper = new DatabaseHelper(getApplicationContext());
            dbHelper.insertMetadataProperty(CONSTANTS.METADATA_SDK_INT, Build.VERSION.SDK_INT + "");
            dbHelper.insertMetadataProperty(CONSTANTS.METADATA_BRAND, Build.BRAND);
            dbHelper.insertMetadataProperty(CONSTANTS.METADATA_MODEL, Build.MODEL);

            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putBoolean("is_device_info_recorded", true);
            editor.apply();
        }
    }


    void initializeListenersAndUI(){

        pollingSwitch = findViewById(R.id.homepage_poll_switch);
        launchFgEventOverviewScreen = findViewById(R.id.btn_fg_event_overview_screen);
        btnExportFGEventData = findViewById(R.id.btn_fg_event_export_fg_events);
        btnExportSensorData = findViewById(R.id.btn_fg_event_export_sensor_events);
        btnExportNetworkData = findViewById(R.id.btn_fg_event_export_network_events);
        btnExportBatteryData = findViewById(R.id.btn_fg_event_export_battery_events);
        btnExportRawDB = findViewById(R.id.btn_fg_event_export_raw_db);

        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        isPollingActive = sharedPref.getBoolean(CONSTANTS.IS_POLLING_ACTIVE, false);
        pollingSwitch.setChecked(isPollingActive);

        launchFgEventOverviewScreen.setOnClickListener(v -> {
            Intent intent = new Intent(this, FgEventsOverview.class);
            startActivity(intent);
        });

        btnExportBatteryData.setOnClickListener(v -> {
            exportBatteryEvents();
        });

        btnExportRawDB.setOnClickListener(v -> {
            exportRawDB();
        });

        btnExportFGEventData.setOnClickListener(view -> {
            exportForegroundEvents();
        });

        btnExportSensorData.setOnClickListener(v -> {
            exportSensorEvents();
        });

        btnExportNetworkData.setOnClickListener(v -> {
            exportNetworkEvents();
        });
    }


    void registerRepeatingServiceCheckerAlarm(){
        AlarmManager alarmMgr;
        PendingIntent alarmIntent;

        alarmMgr = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, CheckFgServiceStatusReceiver.class);
        alarmIntent = PendingIntent.getBroadcast(getApplicationContext(), 0, intent, 0);

        alarmMgr.setInexactRepeating(AlarmManager.RTC_WAKEUP,
            SystemClock.elapsedRealtime(),
            CONSTANTS.CHECK_FG_SERVICE_STATUS_FREQUENCY_MILLISECONDS,
            alarmIntent);
    }

    void registerRepeatingServiceRestarterAlarm(){
        AlarmManager alarmMgr;
        PendingIntent alarmIntent;

        alarmMgr = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, CheckFgServiceStatusHandler.class);
        alarmIntent = PendingIntent.getBroadcast(getApplicationContext(), 0, intent, 0);

        alarmMgr.setInexactRepeating(AlarmManager.RTC_WAKEUP,
                SystemClock.elapsedRealtime(),
                CONSTANTS.CHECK_FG_SERVICE_STATUS_RESTART_FREQUENCY_MILLISECONDS,
                alarmIntent);
    }


    // Helper to check if Foreground Service is already running
    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }


    // Helper to handle changes in 'Start Recording' switch state
    void switchStateChanged(){
        if(pollingSwitch.isChecked()){
            SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putBoolean(CONSTANTS.IS_POLLING_ACTIVE, true);
            editor.apply();

            isPollingActive = true;
            pollingSwitch.setChecked(true);

            Intent startIntent = new Intent(this, ForegroundService.class);
            startIntent.setAction(CONSTANTS.START_FOREGROUND_SERVICE);
            ContextCompat.startForegroundService(getApplicationContext(), startIntent);

            onServiceStartDialog();
        }
        else if (isPollingActive && !pollingSwitch.isChecked()){
            SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putBoolean(CONSTANTS.IS_POLLING_ACTIVE, false);
            editor.apply();

            isPollingActive = false;
            pollingSwitch.setChecked(false);

            Intent stopIntent = new Intent(this, ForegroundService.class);
            stopIntent.setAction(CONSTANTS.STOP_FOREGROUND_SERVICE);
            ContextCompat.startForegroundService(getApplicationContext(), stopIntent);
        }
    }


    // if Usage Access Permission is not available:
    // Then show context UI for the permission.
    // On clicking "Agree & Continue" btn of Context UI, launch activity for Usage Access Settings Intent.
    // Result of activity is handled by @onActivityResult
    void requestUsageStatsPermission() {
        if (!hasUsageStatsPermission(getApplicationContext())) {

            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setMessage("The app requires Usage Access Permission to track your screen activity.\n\nLook for \'Usage Tracker\' in the next screen and grant permission for the app to work properly.");
            builder.setPositiveButton("Agree & Continue", (dialog, which) -> {
                dialog.dismiss();
                startActivityForResult(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS), CONSTANTS.USAGE_ACCESS_REQUEST_CODE);
            });

            AlertDialog dialog = builder.create();
            dialog.setCancelable(false);
            dialog.setCanceledOnTouchOutside(false);

            dialog.show();
        }
        // If Usage Access permission is available, fire OnActivityResult to proceed
        // with checking other permissions
        else{
            onActivityResult(CONSTANTS.USAGE_ACCESS_REQUEST_CODE, 0, null);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CONSTANTS.USAGE_ACCESS_REQUEST_CODE){
            if(hasUsageStatsPermission(getApplicationContext())){
                // Usage Access Permission Granted.
                // Proceed to ask for storage permission next.
//                requestStoragePermission();
                requestLocationPermission();
            }
            else{
                // Usage Access permission not granted.
                // Ask for Usage Access permission again.
                requestUsageStatsPermission();
            }
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == CONSTANTS.FINE_LOCATION_ACCESS_REQUEST_CODE){
            if(ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PERMISSION_GRANTED){
                requestLocationPermission();
            }
        }

        if (requestCode == CONSTANTS.STORAGE_ACCESS_REQUEST_CODE){
            if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PERMISSION_GRANTED){
                // Storage Access Permission Granted.
                // Proceed to ask for location permission next.
                requestLocationPermission();
            }
            else{
                // Storage access permission not granted.
                // Ask for Storage Access permission again.
                requestLocationPermission();
            }
        }
    }


    void requestStoragePermission(){
        if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PERMISSION_GRANTED){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setMessage("The app requires access to your device storage in order to generate and export CSV data files.\n\nPlease grant storage access permission on the next popup.");
            builder.setPositiveButton("Agree & Continue", (dialog, which) -> {
                dialog.dismiss();
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 105);
            });

            AlertDialog dialog = builder.create();
            dialog.setCancelable(false);
            dialog.setCanceledOnTouchOutside(false);

            dialog.show();
        }
    }


    void requestLocationPermission(){
        // API LEVEL 27 & 28 require access to coarse location for Wifi Polling
        if(Build.VERSION.SDK_INT >= 27 && Build.VERSION.SDK_INT <= 28 && ContextCompat.checkSelfPermission(
                MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PERMISSION_GRANTED){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setMessage("The app requires Location Access Permission to track your Network Activity such as Wifi SSID and signal strength. " +
                    "Your location, however, will not be accessed or stored at any point.");
            builder.setPositiveButton("Agree & Continue", (dialog, which) -> {
                dialog.dismiss();
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 101);
            });

            AlertDialog dialog = builder.create();
            dialog.setCancelable(false);
            dialog.setCanceledOnTouchOutside(false);

            dialog.show();
        }

        if(Build.VERSION.SDK_INT > 28 && ContextCompat.checkSelfPermission(
                MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PERMISSION_GRANTED){

            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setMessage("The app requires Location Access Permission to track your Network Activity such as Wifi SSID and signal strength. " +
                    "Your location, however, will not be accessed or stored at any point.\n\nPlease grant permission to access coarse location on the next screen.");
            builder.setPositiveButton("Agree & Continue", (dialog, which) -> {
                dialog.dismiss();
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 101);
            });

            AlertDialog dialog = builder.create();
            dialog.setCancelable(false);
            dialog.setCanceledOnTouchOutside(false);

            dialog.show();
        }

        else if(Build.VERSION.SDK_INT > 28 && ContextCompat.checkSelfPermission(
                MainActivity.this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PERMISSION_GRANTED){

            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setMessage("Starting from Android 8.1, the app also requires access to your location in background to poll wifi details.\n\nPlease grant permission to access to your location in background by going to Settings > Apps > Usage Tracker > Permissions > Location and enabling \'Allow all the time\'.");
            builder.setPositiveButton("Agree & Continue", (dialog, which) -> {
                dialog.dismiss();
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION}, 102);
            });

            AlertDialog dialog = builder.create();
            dialog.setCancelable(false);
            dialog.setCanceledOnTouchOutside(false);

            dialog.show();
        }
    }


    // Helper to check if Usage Access permission is granted.
    static boolean hasUsageStatsPermission(Context context) {
        AppOpsManager appOps = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
        int mode = appOps.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), context.getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    void exportRawDB(){
        DatabaseHelper dbHelper = new DatabaseHelper(getBaseContext());

        File csvFile = dbHelper.exportRawDB();

        Intent intentShareFile = new Intent(Intent.ACTION_SEND);

        if(csvFile.exists()) {
            String mimeType = "application/raw";
            String[] mimeTypeArray = new String[] { mimeType };

            intentShareFile.setType(mimeType);
            Uri uri = FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".provider", csvFile);

            // Add the uri as a ClipData
            intentShareFile.setClipData(new ClipData(
                    "A label describing your file to the user",
                    mimeTypeArray,
                    new ClipData.Item(uri)
            ));

            // EXTRA_STREAM is kept for compatibility with old applications
            intentShareFile.putExtra(Intent.EXTRA_STREAM, uri);

            intentShareFile.putExtra(Intent.EXTRA_SUBJECT, "Usage Tracker - Raw SQLite Database");
            intentShareFile.putExtra(Intent.EXTRA_TEXT, "Sharing SQLite Database of Usage Tracker");
            intentShareFile.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intentShareFile, "Share Raw DB"));
        }
    }

    // Context UI popup when foreground service has been started
    void onServiceStartDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setMessage("Background service for recording activity has been successfully started.\n\nPlease pin/lock this application from recents menu to prevent it from being killed by the OS!");

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();

        dialog.show();
    }


    // Helper to export battery events data as CSV
    void exportBatteryEvents(){
        DatabaseHelper dbHelper = new DatabaseHelper(getBaseContext());

        File csvFile = dbHelper.exportBatteryDB();

        Intent intentShareFile = new Intent(Intent.ACTION_SEND);

        if(csvFile.exists()) {
            String mimeType = "application/csv";
            String[] mimeTypeArray = new String[] { mimeType };

            intentShareFile.setType(mimeType);
            Uri uri = FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".provider", csvFile);

            // Add the uri as a ClipData
            intentShareFile.setClipData(new ClipData(
                    "A label describing your file to the user",
                    mimeTypeArray,
                    new ClipData.Item(uri)
            ));

            // EXTRA_STREAM is kept for compatibility with old applications
            intentShareFile.putExtra(Intent.EXTRA_STREAM, uri);

            intentShareFile.putExtra(Intent.EXTRA_SUBJECT,
                    "Battery Events Data CSV");
            intentShareFile.putExtra(Intent.EXTRA_TEXT, "Sharing Battery Events Data Recorded Using Usage Tracker");
            intentShareFile.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intentShareFile, "Share Battery Events Data CSV File"));
        }
    }


    // Helper to export foreground events data as CSV
    void exportForegroundEvents(){
        DatabaseHelper dbHelper = new DatabaseHelper(getBaseContext());

        File csvFile = dbHelper.exportEventDB();

        Intent intentShareFile = new Intent(Intent.ACTION_SEND);

        if(csvFile.exists()) {
            String mimeType = "application/csv";
            String[] mimeTypeArray = new String[] { mimeType };

            intentShareFile.setType(mimeType);
            Uri uri = FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".provider", csvFile);

            // Add the uri as a ClipData
            intentShareFile.setClipData(new ClipData(
                    "A label describing your file to the user",
                    mimeTypeArray,
                    new ClipData.Item(uri)
            ));

            // EXTRA_STREAM is kept for compatibility with old applications
            intentShareFile.putExtra(Intent.EXTRA_STREAM, uri);

            intentShareFile.putExtra(Intent.EXTRA_SUBJECT,
                    "Foreground Screen Activity Data CSV");
            intentShareFile.putExtra(Intent.EXTRA_TEXT, "Sharing Foreground Screen Activity Data Recorded Using Usage Tracker");
            intentShareFile.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intentShareFile, "Share Foreground Screen Activity Data CSV File"));
        }
    }


    // Helper to export network polling data as CSV
    void exportNetworkEvents(){
        DatabaseHelper dbHelper = new DatabaseHelper(getBaseContext());

        File csvFile = dbHelper.exportNetworkDB();

        Intent intentShareFile = new Intent(Intent.ACTION_SEND);

        if(csvFile.exists()) {
            String mimeType = "application/csv";
            String[] mimeTypeArray = new String[] { mimeType };

            intentShareFile.setType(mimeType);
            Uri uri = FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".provider", csvFile);

            // Add the uri as a ClipData
            intentShareFile.setClipData(new ClipData(
                    "A label describing your file to the user",
                    mimeTypeArray,
                    new ClipData.Item(uri)
            ));

            // EXTRA_STREAM is kept for compatibility with old applications
            intentShareFile.putExtra(Intent.EXTRA_STREAM, uri);

            intentShareFile.putExtra(Intent.EXTRA_SUBJECT, "Network Data CSV");
            intentShareFile.putExtra(Intent.EXTRA_TEXT, "Sharing Network Data Recorded Using Usage Tracker");
            intentShareFile.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intentShareFile, "Share Network Data CSV File"));
        }
    }


    // Helper to export sensor data as CSV
    void exportSensorEvents(){
        DatabaseHelper dbHelper = new DatabaseHelper(getBaseContext());

        File csvFile = dbHelper.exportSensorDB();

        Intent intentShareFile = new Intent(Intent.ACTION_SEND);

        if(csvFile.exists()) {
            String mimeType = "application/csv";
            String[] mimeTypeArray = new String[] { mimeType };

            intentShareFile.setType(mimeType);
            Uri uri = FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".provider", csvFile);

            // Add the uri as a ClipData
            intentShareFile.setClipData(new ClipData(
                    "A label describing your file to the user",
                    mimeTypeArray,
                    new ClipData.Item(uri)
            ));

            // EXTRA_STREAM is kept for compatibility with old applications
            intentShareFile.putExtra(Intent.EXTRA_STREAM, uri);

            intentShareFile.putExtra(Intent.EXTRA_SUBJECT, "Sensor Data CSV");
            intentShareFile.putExtra(Intent.EXTRA_TEXT, "Sharing Sensor Data Recorded Using Usage Tracker");
            intentShareFile.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intentShareFile, "Share Sensor Data CSV File"));
        }
    }
}