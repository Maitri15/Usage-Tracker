package com.sarthak.usagetracker;

import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.util.Date;
import java.util.HashMap;

public class ForegroundService extends Service {

    private final Handler mFileUploadHandler = new Handler();
    private Runnable pollRunnable;

    KeyguardManager keyguardManager;
    boolean isCurrentlyLocked = false, wasPreviouslyLocked = false;

    ConnectivityManager cm;

    private SensorManager mSensorManager;
    private Sensor mAccel, mGyro, mLight, mMagnetic;
    private final float[] accelValues = {0.0f, 0.0f, 0.0f};
    private final float[] gyroValues = {0.0f, 0.0f, 0.0f};
    private final float[] magneticValues = {0.0f, 0.0f, 0.0f};
    private float lightValue = 0.0f;

    private final SensorEventListener mAccelListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            accelValues[0] = event.values[0];
            accelValues[1] = event.values[1];
            accelValues[2] = event.values[2];
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }
    };

    private final SensorEventListener mGyroListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            gyroValues[0] = event.values[0];
            gyroValues[1] = event.values[1];
            gyroValues[2] = event.values[2];
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }
    };

    private final SensorEventListener mMagnetListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
//            Log.e("MAGNETIC_FIELD","X: " + event.values[0] + "\tY: " + event.values[1] + "\tZ: " + event.values[2]);
            magneticValues[0] = event.values[0];
            magneticValues[1] = event.values[1];
            magneticValues[2] = event.values[2];
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    };

    private SensorEventListener mLightListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            lightValue = event.values[0];
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }
    };

    private static final String CHARGING_CONNECTED_ACTION = "android.intent.action.ACTION_POWER_CONNECTED";
    private static final String CHARGING_DISCONNECTED_ACTION = "android.intent.action.ACTION_POWER_DISCONNECTED";

    private BroadcastReceiver yourChargingReceiver;

    PackageManager packageManager;
    String packageName = "", appName = "", lastCheckedPackage = "";

    AudioManager audioManager;
    int currentCallAudioStatus = -1;

    Date startTime;
    DatabaseHelper dbHelper;
    HashMap<String, Integer> appNameIdMap;
    HashMap<String, Integer> ssidIdMap;

    private boolean isPolling = false;
    private int index = 0;


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        // Helper to receive and handle stop command for service
        if(intent != null && intent.getAction().equals(CONSTANTS.STOP_FOREGROUND_SERVICE)){
            stopForeground(true);
            stopSelfResult(CONSTANTS.FOREGROUND_NOTIFICATION_ID);
            isPolling = false;
            return START_NOT_STICKY;
        }

        createNotificationChannel();

        // Create notification to be displayed in foreground.
        Notification notification = createForegroundNotification();

        startForeground(CONSTANTS.FOREGROUND_NOTIFICATION_ID, notification);

        packageManager = getApplicationContext().getPackageManager();

        cm = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);

        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        try { appName = (String) packageManager.getApplicationLabel(packageManager.getApplicationInfo(lastCheckedPackage, PackageManager.GET_META_DATA)); }
        catch (PackageManager.NameNotFoundException e) { appName = packageName == null || packageName.equals("") ? "unknown" : packageName; }

        keyguardManager = (KeyguardManager) getApplicationContext().getSystemService(Context.KEYGUARD_SERVICE);

        registerSensors();

        registerChargingBroadcastReceiver();

        dbHelper = new DatabaseHelper(getApplicationContext());

        lastCheckedPackage = packageName = getForegroundApp(getApplicationContext());
        if(lastCheckedPackage == null){
            Log.e("LAST-CHECKED-PACKAGE", "Null here...1");
        }
        appNameIdMap = dbHelper.getAllRegisteredEvents();
        ssidIdMap = dbHelper.getAllRegisteredSSIDs();
        startTime = new Date();

        pollRunnable = this::poll;

        if (!isPolling) {
            isPolling = true;
            mFileUploadHandler.postDelayed(pollRunnable, 2500);
        }

        Log.e("xyz", "");

        return START_NOT_STICKY;
    }


    void registerChargingBroadcastReceiver(){
        final IntentFilter theFilter = new IntentFilter();
        theFilter.addAction(CHARGING_CONNECTED_ACTION);
        theFilter.addAction(CHARGING_DISCONNECTED_ACTION);
        this.yourChargingReceiver = new BroadcastReceiver() {

            @Override
            public void onReceive(Context context, Intent intent) {
                BatteryManager bm = (BatteryManager) context.getSystemService(BATTERY_SERVICE);
                int percentage = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);

                if (intent.getAction().equals(CHARGING_CONNECTED_ACTION)) { dbHelper.insertBatteryEvent("power_connected", percentage, new Date()); }
                else if (intent.getAction().equals(CHARGING_DISCONNECTED_ACTION)) { dbHelper.insertBatteryEvent("power_disconnected", percentage, new Date()); }
            }
        };
        // Registers the receiver so that your service will listen for
        // broadcasts
        this.registerReceiver(this.yourChargingReceiver, theFilter);
    }


    void registerSensors(){
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        mAccel = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mLight = mSensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        mGyro = mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        mMagnetic = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

        if (mAccel != null) {
            mSensorManager.registerListener(mAccelListener, mAccel, SensorManager.SENSOR_DELAY_NORMAL);
        }

        if (mGyro != null){
            mSensorManager.registerListener(mGyroListener, mGyro, SensorManager.SENSOR_DELAY_NORMAL);
        }

        if (mLight != null){
            mSensorManager.registerListener(mLightListener, mLight, SensorManager.SENSOR_DELAY_NORMAL);
        }

        if (mMagnetic != null){
            mSensorManager.registerListener(mMagnetListener, mMagnetic, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }


    void poll() {

        Date timestamp = new Date();
        index++;

        if(index % CONSTANTS.POLL_SENSOR_FREQUENCY_FACTOR == 0){
            dbHelper.insertSensorDataSample(accelValues, gyroValues, magneticValues, lightValue, timestamp);
            index = 0;
        }

        NetworkInfo networkInfo =  cm.getActiveNetworkInfo();

        boolean isWifiConnected =  (networkInfo != null &&
                networkInfo.isConnected() &&
                networkInfo.getType() == ConnectivityManager.TYPE_WIFI);

        boolean isMobileDataConnected = networkInfo != null &&
                networkInfo.isConnected() &&
                networkInfo.getType() == ConnectivityManager.TYPE_MOBILE;

        if(isWifiConnected){
            WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiInfo wifiInfo = wifiManager.getConnectionInfo();
            addNetworkEventToDatabase(wifiInfo.getSSID().replaceAll("\"", ""), 1, wifiInfo.getRssi(), timestamp);
        } else if(isMobileDataConnected){
            Log.e("WIFI TYPE", "MOBILE DATA");
            addNetworkEventToDatabase(CONSTANTS.NETWORK_SSID_MOBILE_DATA, -1, 0f, timestamp);
        } else {
//            Log.e("WIFI TYPE", "NO INTERNET");
            addNetworkEventToDatabase(CONSTANTS.NETWORK_SSID_NO_NETWORK, -1, 0f, timestamp);
        }

        pollAudioDeviceStatus();

        // get current foreground app
        packageName = getForegroundApp(getApplicationContext());
//        Log.e("FG_DEBUG", "package_name = " + packageName);

        // get current state of screen
        // i.e. locked or unlocked
        keyguardManager = (KeyguardManager) getApplicationContext().getSystemService(Context.KEYGUARD_SERVICE);
        isCurrentlyLocked = keyguardManager.isKeyguardLocked();

        // Device was previously unlocked, but has now been locked.
        if (!wasPreviouslyLocked && isCurrentlyLocked){
            appName = CONSTANTS.DEVICE_LOCKED_APP_NAME;
            packageName = CONSTANTS.DEVICE_LOCKED_PACKAGE_NAME;
            wasPreviouslyLocked = true;
        }
        else if(isCurrentlyLocked){
            appName = CONSTANTS.DEVICE_LOCKED_APP_NAME;
            packageName = CONSTANTS.DEVICE_LOCKED_PACKAGE_NAME;
            wasPreviouslyLocked = true;
        }
        else{
            wasPreviouslyLocked = false;
        }

        if ( (packageName != null && packageName.equals(lastCheckedPackage)) ){
            // do nothing
//            Log.e("FG_DEBUG", "do-nothing IF-BLOCK");
        }

        // Previous app has been closed and a new app has been opened.
        // Mark previous app as closed and add to database.
        // Mark current app as running and record its start time.
        else {
//            Log.e("FG_DEBUG", "ELSE-BLOCK");
            // get app name from the package name of foreground app
            if(!lastCheckedPackage.equals(CONSTANTS.DEVICE_LOCKED_PACKAGE_NAME)) {
                try { appName = (String) packageManager.getApplicationLabel(packageManager.getApplicationInfo(lastCheckedPackage, PackageManager.GET_META_DATA)); }

                // if appName is not found, set packageName as appName
                catch (PackageManager.NameNotFoundException e) {
                    appName = packageName == null || packageName.equals("") ? "unknown" : packageName;
                }
            }

            // add the application usage event to database
            addApplicationEventToDatabase(lastCheckedPackage, appName, startTime, timestamp);

            // reset startTime for newly opened app
            startTime = new Date();
            lastCheckedPackage = packageName;
        }

        // Queue the "poll" runnable with a delay.
        if(isPolling){ mFileUploadHandler.postDelayed(pollRunnable, CONSTANTS.POLL_FREQUENCY_MILLISECONDS); }
    }


    void pollAudioDeviceStatus(){
        int newStatus = audioManager.getMode();

        if(newStatus != currentCallAudioStatus){
            switch (newStatus){
                case AudioManager.MODE_NORMAL:
                    dbHelper.insertCallStatusEvent("MODE_NORMAL", new Date());
                    break;
                case AudioManager.MODE_IN_CALL:
                    dbHelper.insertCallStatusEvent("MODE_IN_CALL", new Date());
                    break;
                case AudioManager.MODE_IN_COMMUNICATION:
                    dbHelper.insertCallStatusEvent("MODE_IN_COMMUNICATION", new Date());
                    break;
                case AudioManager.MODE_RINGTONE:
                    dbHelper.insertCallStatusEvent("MODE_RINGTONE", new Date());
                    break;
            }
            currentCallAudioStatus = newStatus;
        }
    }


    public String getForegroundApp(final Context context) {
        if(!MainActivity.hasUsageStatsPermission(getApplicationContext()))
            return null;

        String foregroundApp = "dummy";

        UsageStatsManager mUsageStatsManager = (UsageStatsManager) context.getSystemService(Service.USAGE_STATS_SERVICE);
        long time = System.currentTimeMillis();

        UsageEvents usageEvents = mUsageStatsManager.queryEvents(time - 1000 * 3600, time);
        UsageEvents.Event event = new UsageEvents.Event();
        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event);
            if(event.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                foregroundApp = event.getPackageName();
            }
        }

        return foregroundApp ;
    }


    void addApplicationEventToDatabase(String packageName, String appName, Date startTime, Date endTime) {
        Log.e("FG_ERROR", "Called for : " + packageName);
        int ID;
        if(!appNameIdMap.containsKey(appName)){
            ID = dbHelper.registerEvent(packageName, appName);
            appNameIdMap.put(appName, ID);
        }
        else{
            ID = appNameIdMap.get(appName);
        }

        dbHelper.insertEvent(packageName, appName, ID, startTime, endTime);
    }


    void addNetworkEventToDatabase(String ssid, int isWifi, float strength, Date timestamp) {
        int ID;
        if(!ssidIdMap.containsKey(ssid)){
            ID = dbHelper.registerSSID(ssid);
            ssidIdMap.put(ssid, ID);
        }
        else{
            ID = ssidIdMap.get(ssid);
        }

        dbHelper.insertNetworkEvent(ssid, ID, isWifi, strength, timestamp);
    }


    Notification createForegroundNotification(){

        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);

        return new NotificationCompat.Builder(this, "Foreground Service Channel ID")
                .setContentText("Usage Tracker is running...")
                .setSmallIcon(R.drawable.activity_tracker_icon)
                .setContentIntent(pendingIntent)
                .build();
    }


    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    "Foreground Service Channel ID",
                    "Foreground Service Channel",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }
}