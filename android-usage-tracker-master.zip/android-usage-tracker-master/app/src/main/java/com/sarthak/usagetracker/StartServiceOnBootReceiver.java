package com.sarthak.usagetracker;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

public class StartServiceOnBootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        registerRepeatingServiceCheckerAlarm(context);
        registerRepeatingServiceRestarterAlarm(context);

        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(context);
        boolean isPollingActive = sharedPref.getBoolean(CONSTANTS.IS_POLLING_ACTIVE, false);

        Toast.makeText(context, isPollingActive + ": is polling active", Toast.LENGTH_LONG).show();

        if(!isMyServiceRunning(context, ForegroundService.class) && isPollingActive) {
            Intent startIntent = new Intent(context, ForegroundService.class);
            startIntent.setAction(CONSTANTS.START_FOREGROUND_SERVICE);
            ContextCompat.startForegroundService(context, startIntent);
        }

        Intent intent2 = new Intent(context, CheckFgServiceStatusHandler.class);
        boolean alarmUp = (PendingIntent.getBroadcast(context, 0,
                intent2,
                PendingIntent.FLAG_NO_CREATE) != null);

        if (alarmUp) {
            Log.d("myTag", "Alarm is already active");
        }
    }

    private boolean isMyServiceRunning(Context context, Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    void registerRepeatingServiceCheckerAlarm(Context context){
        AlarmManager alarmMgr;
        PendingIntent alarmIntent;

        alarmMgr = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, CheckFgServiceStatusReceiver.class);
        alarmIntent = PendingIntent.getBroadcast(context, 0, intent, 0);

        alarmMgr.setInexactRepeating(AlarmManager.RTC_WAKEUP,
                SystemClock.elapsedRealtime(),
                CONSTANTS.CHECK_FG_SERVICE_STATUS_FREQUENCY_MILLISECONDS,
                alarmIntent);
    }

    void registerRepeatingServiceRestarterAlarm(Context context){
        AlarmManager alarmMgr;
        PendingIntent alarmIntent;

        alarmMgr = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, CheckFgServiceStatusHandler.class);
        alarmIntent = PendingIntent.getBroadcast(context, 0, intent, 0);

        alarmMgr.setInexactRepeating(AlarmManager.RTC_WAKEUP,
                SystemClock.elapsedRealtime(),
                CONSTANTS.CHECK_FG_SERVICE_STATUS_RESTART_FREQUENCY_MILLISECONDS,
                alarmIntent);
    }
}
