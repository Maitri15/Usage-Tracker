package com.sarthak.usagetracker;

import android.content.Context;
import android.content.pm.PackageManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.widget.ImageViewCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class FgEventAdapter extends RecyclerView.Adapter<FgEventAdapter.ViewHolder> {

    private Context context;
    private int resource;
    List<FgEventObject> list;

    public FgEventAdapter(Context context, int resource, List<FgEventObject> list) {
        this.context = context;
        this.resource = resource;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(resource, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.appName.setText(list.get(position).getAppName());
        holder.date.setText(list.get(position).getStartDateAsString());
        holder.time.setText(list.get(position).getStartTimeAsString());
        try {
            holder.packageIcon.setImageDrawable(list.get(position).getPackageIcon(context));
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        List<Long> duration = list.get(position).getDuration();
        String durationStr = "";

        if (duration.get(0) != 0){
            durationStr = durationStr + duration.get(0) + " days";
        }

        if (duration.get(1) != 0){
            durationStr = durationStr + duration.get(1) + " h ";
        }

        if (duration.get(2) != 0){
            durationStr = durationStr + duration.get(2) + " m ";
        }

        if (duration.get(3) != 0){
            durationStr = durationStr + duration.get(3) + " s";
        }

        holder.duration.setText(durationStr);
    }

    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private TextView appName, date, time, duration;
        private ImageView packageIcon;

        public ViewHolder(@NonNull View view) {
            super(view);

            this.appName = view.findViewById(R.id.fg_item_appName);
            this.date = view.findViewById(R.id.fg_item_date);
            this.time = view.findViewById(R.id.fg_item_time);
            this.duration = view.findViewById(R.id.fg_item_duration);
            this.packageIcon = view.findViewById(R.id.fg_item_packageIcon);
        }
    }
}
