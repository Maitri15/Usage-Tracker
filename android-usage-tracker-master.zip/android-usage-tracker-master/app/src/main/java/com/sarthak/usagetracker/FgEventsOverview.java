package com.sarthak.usagetracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.core.util.Pair;

import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class FgEventsOverview extends AppCompatActivity {

    private RecyclerView fgEventRecycler;
    private FgEventAdapter fgEventRecyclerAdapter;
    private FgEventCumulativeAdapter fgEventCumulativeRecyclerAdapter;
    TextView selectedDateRange;

    private LinearLayoutCompat dateSelectorLinearLayout;
    SwitchMaterial showCumulativeSwitch;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    private List<FgEventObject> fgEventObjectList;
    DatabaseHelper db;

    Boolean showCumulative = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fg_events_overview);

        showCumulativeSwitch = findViewById(R.id.fg_overview_cumulative_switch);

        db = new DatabaseHelper(getApplicationContext());

        try {
            String startDate = dateFormat.format(new Date());
            String endDate = dateFormat.format(new Date());
            fgEventObjectList = db.getAllFgEvents(startDate, endDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        fgEventRecycler = findViewById(R.id.fg_overview_recycler);

        fgEventRecyclerAdapter = new FgEventAdapter(FgEventsOverview.this, R.layout.foreground_event_item, fgEventObjectList);
        fgEventCumulativeRecyclerAdapter = new FgEventCumulativeAdapter(FgEventsOverview.this, R.layout.foreground_event_item, fgEventObjectList);
        fgEventRecycler.setLayoutManager(new LinearLayoutManager(FgEventsOverview.this, LinearLayoutManager.VERTICAL, false));
        fgEventRecycler.setAdapter(fgEventRecyclerAdapter);


        dateSelectorLinearLayout = findViewById(R.id.fg_overview_LL_layout);
        dateSelectorListener();
        selectedDateRange = findViewById(R.id.fg_overview_selected_dateRange);

        pollingSwitchListener();
    }

    void pollingSwitchListener(){
        showCumulativeSwitch.setOnClickListener(v -> switchStateChanged());
    }

    void switchStateChanged(){
        if(showCumulativeSwitch.isChecked()){
            fgEventRecycler.setAdapter(fgEventCumulativeRecyclerAdapter);
        }
        else {
            fgEventRecycler.setAdapter(fgEventRecyclerAdapter);
        }
    }


    void dateSelectorListener(){
        dateSelectorLinearLayout.setOnClickListener(v -> {
            MaterialDatePicker.Builder materialDateBuilder = MaterialDatePicker.Builder.dateRangePicker();
            materialDateBuilder.setTheme(R.style.ThemeOverlay_MaterialComponents_MaterialCalendar);

            materialDateBuilder.setTitleText("Select a range of date");

            final MaterialDatePicker materialDatePicker = materialDateBuilder.build();

            materialDatePicker.addOnPositiveButtonClickListener(this::onPositiveButtonClick);

            materialDatePicker.show(getSupportFragmentManager(), "MATERIAL_DATE_RANGE_PICKER");
        });
    }

    void updateRecyclerView(String startDate, String endDate){

        try {
            fgEventRecycler.getRecycledViewPool().clear();

            fgEventObjectList.clear();
            fgEventRecyclerAdapter.notifyDataSetChanged();

            fgEventObjectList.addAll(db.getAllFgEvents(startDate, endDate));
            fgEventRecyclerAdapter.notifyDataSetChanged();
        } catch (ParseException e) {
            Log.e("DATE PICKER ERROR", e.toString());
        }
    }

    private void onPositiveButtonClick(Object selection) {
        Pair<Long, Long> obj = (Pair<Long, Long>) selection;
        String startDate = dateFormat.format(new Date(obj.first));
        String endDate = dateFormat.format(new Date(obj.second));

        SimpleDateFormat format = new SimpleDateFormat("dd MMM, yy");
        String dateRange = format.format(new Date(obj.first)) + " - " + format.format(new Date(obj.second));
        selectedDateRange.setText(dateRange);

        updateRecyclerView(startDate, endDate);
    }
}