package com.sarthak.usagetracker;

public class CONSTANTS {

    static final int FOREGROUND_NOTIFICATION_ID = 1;

    static final int USAGE_ACCESS_REQUEST_CODE = 100;
    static final int STORAGE_ACCESS_REQUEST_CODE = 105;
    static final int FINE_LOCATION_ACCESS_REQUEST_CODE = 101;

    static final int POLL_FREQUENCY_MILLISECONDS = 5000;
    static final int POLL_SENSOR_FREQUENCY_FACTOR = 3;
    static final int CHECK_FG_SERVICE_STATUS_FREQUENCY_MILLISECONDS = 1000 * 60 * 60;
    static final int CHECK_FG_SERVICE_STATUS_RESTART_FREQUENCY_MILLISECONDS = 1000 * 60 * 30;

    static final String IS_POLLING_ACTIVE = "is_polling_active";
    static final String STOP_FOREGROUND_SERVICE = "stop_foreground_service";
    static final String START_FOREGROUND_SERVICE = "start_foreground_service";

    static final String METADATA_TABLE = "device_metadata";
    static final String METADATA_PROPERTY_NAME_COL = "property";
    static final String METADATA_PROPERTY_VALUE_COL = "value";
    static final String METADATA_SDK_INT = "android_api_level";
    static final String METADATA_BRAND = "device_brand";
    static final String METADATA_MODEL = "device_model";

    static final String DEVICE_LOCKED_APP_NAME = "device_locked";
    static final String DEVICE_LOCKED_PACKAGE_NAME = "device_locked_package";
    
    static final String NETWORK_SSID_MOBILE_DATA = "Mobile Data";
    static final String NETWORK_SSID_NO_NETWORK = "No Internet Network";

    // Database Constants
    static final String DATABASE_NAME = "usage_tracker_db";
    static final String ID_COL = "id";

    static final String FG_EVENT_TABLE = "foreground_events";
    static final String EVENT_ID_COL = "event_id";
    static final String START_DATE_COL = "start_date";
    static final String END_DATE_COL = "end_date";
    static final String START_TIME_COL = "start_time";
    static final String END_TIME_COL = "end_time";
    static final String START_TIMEZONE_COL = "start_timezone";
    static final String END_TIMEZONE_COL = "end_timezone";

    static final String FG_EVENT_DETAILS_TABLE = "foreground_event_details";
    static final String EVENT_NAME_COL = "event_name";
    static final String EVENT_PACKAGE_NAME_COL = "event_package_name";

    static final String BATTERY_EVENTS_TABLE = "battery_events";
    static final String BATTERY_DATE_COL = "date";
    static final String BATTERY_TIME_COL = "time";
    static final String BATTERY_EVENT_TYPE = "event_type";
    static final String BATTERY_TIMEZONE_COL = "timezone";
    static final String BATTERY_PERCENTAGE_COL = "percentage";

    static final String SENSOR_DATA_TABLE = "sensor_data";
    static final String SENSOR_LIGHT_COL = "light";
    static final String SENSOR_ACCEL_X_COL = "accel_x";
    static final String SENSOR_ACCEL_Y_COL = "accel_y";
    static final String SENSOR_ACCEL_Z_COL = "accel_z";
    static final String SENSOR_GYRO_X_COL = "gyro_x";
    static final String SENSOR_GYRO_Y_COL = "gyro_y";
    static final String SENSOR_GYRO_Z_COL = "gyro_z";
    static final String SENSOR_MAGNET_X_COL = "mag_x";
    static final String SENSOR_MAGNET_Y_COL = "mag_y";
    static final String SENSOR_MAGNET_Z_COL = "mag_z";
    static final String SENSOR_DATE_COL = "date";
    static final String SENSOR_TIME_COL = "time";
    static final String SENSOR_TIMEZONE_COL = "timezone";

    static final String NETWORK_EVENTS_TABLE = "network_events";
    static final String NETWORK_EVENT_ID_COL = "id";
    static final String NETWORK_EVENT_DATE_COL = "date";
    static final String NETWORK_EVENT_TIME_COL = "time";
    static final String NETWORK_EVENT_TIMEZONE_COL = "timezone";
    static final String NETWORK_EVENT_SSID_ID = "ssid_id";
    static final String NETWORK_EVENT_ISWIFI_COL = "is_wifi";
    static final String NETWORK_STRENGTH_COL = "strength";

    static final String NETWORK_DATA_SSID_TABLE = "network_details";
    static final String NETWORK_DATA_SSID = "ssid";
    static final String NETWORK_DATA_SSID_ID = "id";

    static final String CALL_STATUS_TABLE = "call_status";
    static final String CALL_MODE_COL = "mode";
    static final String CALL_STATUS_DATE_COL = "date";
    static final String CALL_STATUS_TIME_COL = "time";
    static final String CALL_STATUS_TIMEZONE_COL = "timezone";
}